var oriH1;
var oriH2;
var interval;
var secondsToEvent;
var secondsToEventInterval;
var date;
$(window).ready(function(){
	var vars = [];
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++){
      hash = hashes[i].split('=');
      vars.push(hash[0]);
      vars[hash[0]] = unescape(hash[1]);
    }
	//?t=Click here to create your own meeting&d=17:00:29 GMT-0500 (EST)03/29/2012
	var title = vars['t'] || 'Click here to create your own meeting';
	
	
	if(vars['d']){
		if(isNaN(vars['d'])){
			date = new Date(vars['d']);
		}else{
			date = new Date(parseInt(vars['d']));	
		}
	}else{
		date = new Date();
	}
	
	$('#question p').hide();
	$("#question h2").html(title);
	
	$("#question h1").html(date.toString());//date.toTimeString() + '<br/>' + date.toLocaleDateString());
	$("#question h2").click(function(){
			this.contentEditable='true';
	});
	
	$("#question h1").click(function(){
			this.contentEditable='true';
	});
	
	if(vars['x']!='cd'){
		$("#question h1").keypress(updateLink);
		$("#question h2").keypress(updateLink);
	}else{
		secondsToEvent = parseInt((date.getTime() - new Date().getTime() ) /1000);
		secondsToEventInterval = setInterval(updateCounter,1000);
		updateCounter();
	}
	
	oriH1 = date.toTimeString() + '<br/>' + date.toLocaleDateString();
	oriH2 = title;
	
	
});

function updateLink(){
	clearInterval(interval);
	interval = setInterval(showUpdate,1000);
	
	$('#question p').show(1);
	$("#linkline").html("I'm listening to you ;) One second after you finish  I'll create a link for your meeting, your welcome.");
}
function showUpdate(){
	var d = new Date($("#question h1").text());
	$('#question p').show(1);
	var outbound = "<a href='http://butwhenisit.com/?t="+$("#question h2").text()+"&d="+d.getTime()+"'>"+$("#question h2").text()+"</a>";
	$("#linkline").html("Your New Link: <b>" + outbound +"</b>");/* +
						"<br/>As html code:<xmp>"+outbound+"</xmp>");*/
	
}

function updateCounter(){
	secondsToEvent--;
	if(secondsToEvent<0){
		$("#question h1").html('Meeting started at' + date.toString() );
	}else{
		var out = "";
		
		var base = secondsToEvent;
		var sec = base % 60;
		base = parseInt(base/60);
		var mi = base %60;
		base = parseInt(base/60);
		var hour = base %24;
		base = parseInt(base/24);
		
		if(base>1) out = base +" Days ";
		else if(base==1) out = base + " Day ";
		
		
		$("#question h1").html(out +format(hour)+":"+format(mi)+":"+format(sec) );
	}
}

function format(num,len){
	if(!len) len=2;
	var str = num.toString();
	var str_len = str.length;
	if(str_len <len){
		for(var i=str_len; i<len; i++) str = "0" + str;	
	}
	return str;
}